#include <pthread.h>
#include <semaphore.h>
#include <iostream>
#include <cstdlib>
#include <unistd.h>
#include <sys/time.h>
#include <vector>

// constant values
#define MAX_BUFFER_SIZE 32
#define MAX_CONSUMERS 10

int *buf;                  // buffer array allowing for circular queue
int bufsize = 1;           // min buffer size 
int num_cons = 1;          // min number of consumers 
int prodIndex = 0;         // producer index
int consIndex = 0;         // consumer index

sem_t empty;         // counts empty slots in buffer
sem_t filled;        // counts filled slots in buffer
sem_t mutex;         // mutual exclusion

// barrier synchronization part
sem_t barrier_sem;                     // semaphore for the barrier
pthread_mutex_t barrier_mutex = PTHREAD_MUTEX_INITIALIZER;
int barrier_count = 0;                 // count of threads that reached the barrier

struct timeval program_start, program_end;

long producer_wait_sec = 0;
long producer_wait_usec = 0;

// func to calculate time difference
void time_diff(struct timeval *start, struct timeval *end, long *sec, long *usec) {
    *sec = end->tv_sec - start->tv_sec;
    *usec = end->tv_usec - start->tv_usec;
    if (*usec < 0) {
        (*sec)--;
        *usec += 1000000;
    }
}

/* pass the number of consumer threads to the producer thread;
allows the producer to know how many -1 termination signals it needs 
to place in the buffer (one for each consumer).*/
struct ProducerArgs {
    int num_cons;
};

void* producer(void* args) {
    ProducerArgs *prod_args = (ProducerArgs*) args;
    int num_cons = prod_args->num_cons;
    int item;
    struct timeval wait_start, wait_end;
    long total_wait_sec = 0;
    long total_wait_usec = 0;

    while (1) {
        // read input
        printf("Please input an integer value: \n");
        if (scanf("%d", &item) != 1) {
            std::cerr << "Failed to read integer. Exiting producer.\n";
            // Insert termination signals for consumers
            for (int i = 0; i < num_cons; ++i) {
                sem_wait(&empty);
                sem_wait(&mutex);
                buf[prodIndex] = -1;
                prodIndex = (prodIndex + 1) % bufsize;
                sem_post(&mutex);
                sem_post(&filled);
            }
            break;
        }

        // start record wait start time before waiting on empty_slots
        gettimeofday(&wait_start, NULL);
        sem_wait(&empty); // wait for empty slot
        // record wait end time after successfully waiting
        gettimeofday(&wait_end, NULL);
        // calc wait time
        long sec_diff, usec_diff;
        time_diff(&wait_start, &wait_end, &sec_diff, &usec_diff);
        total_wait_sec += sec_diff;
        total_wait_usec += usec_diff;

        // crit section
        sem_wait(&mutex);

        // add item to buffer
        buf[prodIndex] = item;
        prodIndex = (prodIndex + 1) % bufsize;

        // exiting critical section
        sem_post(&mutex);

        // signal that a new item is available
        sem_post(&filled);

        if (item == -1) {
            // after placing -1, place additional -1 for each consumer
            for (int i = 1; i < num_cons; ++i) {
                sem_wait(&empty);
                sem_wait(&mutex);
                buf[prodIndex] = -1;
                prodIndex = (prodIndex + 1) % bufsize;
                sem_post(&mutex);
                sem_post(&filled);
            }
            break;
        }
    }

    // calc total producer wait time
    producer_wait_sec = total_wait_sec;
    producer_wait_usec = total_wait_usec;

    pthread_exit(NULL);
}

/* pass a unique identifier to each consumer thread.
each consumer uses its id to identify itself when printing 
its total sum. */
struct ConsumerArgs {
    int id;
};

void barrier_sync(int total_threads) {
    pthread_mutex_lock(&barrier_mutex);
    barrier_count++;
    if (barrier_count == total_threads) {
        // release all threads
        for (int i = 0; i < total_threads; ++i) {
            sem_post(&barrier_sem);
        }
    }
    pthread_mutex_unlock(&barrier_mutex);
    // wait on semaphore
    sem_wait(&barrier_sem);
}

void* consumer(void* args) {
    ConsumerArgs *cons_args = (ConsumerArgs*) args;
    int id = cons_args->id;
    int total = 0;
    int item;

    while (true) {
        sem_wait(&filled);   // wait for a filled slot
        sem_wait(&mutex);    // enter critical section

        // consume item from buffer
        item = buf[consIndex];
        consIndex = (consIndex + 1) % bufsize;

        sem_post(&mutex);    // exit critical section
        sem_post(&empty);    // signal that a slot is free

        if (item == -1) {
            // do not add -1 to total
            // break the loop to terminate
            break;
        }

        // add item to total
        total += item;

        // delay for 1 second
        sleep(1);
    }

    // implement barrier before termination 
    barrier_sync(num_cons);

    // print consumer's total
    printf("Consumer %d total is %d\n", id, total);

    pthread_exit(NULL);
}

int main(int argc, char* argv[]) {
    // parse command line arguments
    if (argc > 1) {
        bufsize = atoi(argv[1]);
        if (bufsize < 1) bufsize = 1;
        if (bufsize > MAX_BUFFER_SIZE) bufsize = MAX_BUFFER_SIZE;
    }
    if (argc > 2) {
        num_cons = atoi(argv[2]);
        if (num_cons < 1) num_cons = 1;
        if (num_cons > MAX_CONSUMERS) num_cons = MAX_CONSUMERS;
    }

    // allocate buffer
    buf = new int[bufsize];

    // initialize semaphores
    sem_init(&empty, 0, bufsize);
    sem_init(&filled, 0, 0);
    sem_init(&mutex, 0, 1);
    sem_init(&barrier_sem, 0, 0); // initialize barrier semaphore

    // get program start time
    gettimeofday(&program_start, NULL);

    // create producer thread
    pthread_t producer_thread;
    ProducerArgs producer_args;
    producer_args.num_cons = num_cons;

    if (pthread_create(&producer_thread, NULL, producer, &producer_args) != 0) {
        std::cerr << "Error creating producer thread.\n";
        // cleanup before exiting
        delete[] buf;
        return EXIT_FAILURE;
    }

    // create consumer threads
    std::vector<pthread_t> consumer_threads(num_cons);
    std::vector<ConsumerArgs> consumer_args_list(num_cons);
    for (int i = 0; i < num_cons; ++i) {
        consumer_args_list[i].id = i; // assign unique ID starting from 0
        if (pthread_create(&consumer_threads[i], NULL, consumer, &consumer_args_list[i]) != 0) {
            std::cerr << "Error creating consumer thread " << (i + 1) << ".\n";
            // handle partial thread creation if necessary
            // for simplicity, exit here
            delete[] buf;
            return EXIT_FAILURE;
        }
    }

    // wait for producer thread to finish
    if (pthread_join(producer_thread, NULL) != 0) {
        std::cerr << "Error joining producer thread.\n";
        // continue to join consumers
    }

    // wait for consumer threads to finish
    for (int i = 0; i < num_cons; ++i) {
        if (pthread_join(consumer_threads[i], NULL) != 0) {
            std::cerr << "Error joining consumer thread " << (i + 1) << ".\n";
        }
    }

    // get program end time
    gettimeofday(&program_end, NULL);

    // calculate total program time
    long prog_sec, prog_usec;
    time_diff(&program_start, &program_end, &prog_sec, &prog_usec);

    // print producer wait time
    printf("Total producer wait time is %ld seconds and %ld microseconds\n", producer_wait_sec, producer_wait_usec);

    // print program time
    printf("Program time is %ld seconds and %ld microseconds\n", prog_sec, prog_usec);

    // cleanup
    sem_destroy(&empty);
    sem_destroy(&filled);
    sem_destroy(&mutex);
    sem_destroy(&barrier_sem);
    pthread_mutex_destroy(&barrier_mutex);
    delete[] buf;

    return 0;
}